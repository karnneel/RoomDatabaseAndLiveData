package com.mindtree.m1045247.demolivedata.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PeopleOBJ {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("phone")
    @Expose
    private String phone;

    /**
     * No args constructor for use in serialization
     */
    public PeopleOBJ() {
    }

    /**
     * @param phone
     * @param name
     * @param image
     */
    public PeopleOBJ(String name, String image, String phone) {
        super();
        this.name = name;
        this.image = image;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}