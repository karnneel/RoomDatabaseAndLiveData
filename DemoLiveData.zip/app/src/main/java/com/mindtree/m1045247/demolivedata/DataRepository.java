package com.mindtree.m1045247.demolivedata;


import android.app.Application;
import android.os.AsyncTask;

import com.mindtree.m1045247.demolivedata.dao.BooksDAO;
import com.mindtree.m1045247.demolivedata.database.AppDatabase;
import com.mindtree.m1045247.demolivedata.entity.Books;

import java.util.List;

import androidx.lifecycle.LiveData;


/**
 * Repository handling the work with products and comments.
 */
public class DataRepository {

    private BooksDAO booksDAO;
    private LiveData<List<Books>> mAllBooks;

    public DataRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        booksDAO = db.booksDao();
    }

    public LiveData<List<Books>> getAllBooks() {
        mAllBooks = booksDAO.loadAllBooks();
        return mAllBooks;
    }

    public void insert(List<Books> booksList) {
        new insertAsyncTask(booksDAO, booksList).execute();
    }

    private static class insertAsyncTask extends AsyncTask<Void, Void, Void> {

        private List<Books> mBooksList;
        private BooksDAO mAsyncTaskDao;

        insertAsyncTask(BooksDAO dao, List<Books> booksList) {
            mAsyncTaskDao = dao;
            this.mBooksList = booksList;
        }


        @Override
        protected Void doInBackground(Void... voids) {
            mAsyncTaskDao.insertBooksIntoDB(mBooksList);
            return null;
        }
    }
}
