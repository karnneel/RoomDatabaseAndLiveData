package com.mindtree.m1045247.demolivedata.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mindtree.m1045247.demolivedata.R;
import com.mindtree.m1045247.demolivedata.entity.Books;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BooksAdapter extends RecyclerView.Adapter<BooksAdapter.BooksViewHolder> {


    private Context mContext;
    private List<Books> booksList;

    public BooksAdapter(Context mContext, List<Books> booksList) {
        this.mContext = mContext;
        this.booksList = booksList;
    }

    @NonNull
    @Override
    public BooksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new BooksViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.books_item, parent, false), mContext);
    }

    @Override
    public void onBindViewHolder(@NonNull BooksViewHolder holder, int position) {
        holder.bindView(booksList.get(position), position);

    }


    public void setBooks(List<Books> words) {
        booksList = words;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return booksList.size();
    }

    public class BooksViewHolder extends RecyclerView.ViewHolder {

        private TextView bookName;
        private TextView booksDescription;

        public BooksViewHolder(View itemView, Context mContext) {
            super(itemView);

            bookName = itemView.findViewById(R.id.booksName);
            booksDescription = itemView.findViewById(R.id.booksDescription);
        }

        public void bindView(Books books, int position) {
            bookName.setText(books.getBookName());
            booksDescription.setText(books.getBookDescription());
        }
    }
}
