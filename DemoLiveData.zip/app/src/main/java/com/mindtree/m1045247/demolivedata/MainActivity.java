package com.mindtree.m1045247.demolivedata;


import android.os.Bundle;

import com.mindtree.m1045247.demolivedata.viewmodel.BooksViewModel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;


public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerViewBooks;
    BooksViewModel booksViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Add product list fragment if this is first creation
        if (savedInstanceState == null) {
            BooksFragment fragment = new BooksFragment();

            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, fragment, BooksFragment.TAG).commit();
        }

      /*  recyclerViewBooks = findViewById(R.id.rv_booksList);
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this);
        recyclerViewBooks.setLayoutManager(mLayoutManager);


        booksViewModel = ViewModelProviders.of(MainActivity.this).get(BooksViewModel.class);




        booksViewModel.getBooksList(MainActivity.this).observe(this, new Observer<List<Books>>() {
            @Override
            public void onChanged(@Nullable List<Books> myProducts) {
                if (myProducts != null) {

                } else {
                }

            }
        });*/
    }



}
