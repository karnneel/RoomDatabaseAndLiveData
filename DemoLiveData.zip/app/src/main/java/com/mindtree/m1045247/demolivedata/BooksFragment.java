package com.mindtree.m1045247.demolivedata;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mindtree.m1045247.demolivedata.adapter.BooksAdapter;
import com.mindtree.m1045247.demolivedata.entity.Books;
import com.mindtree.m1045247.demolivedata.viewmodel.BooksViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class BooksFragment extends Fragment {
    public static final String TAG = "";
    private BooksViewModel booksViewModel;
    private RecyclerView recyclerViewBooks;

    private List<Books> booksList = new ArrayList<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        booksViewModel = ViewModelProviders.of(this).get(BooksViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.books_list_fragment, container, false);
        recyclerViewBooks = view.findViewById(R.id.rvBooksList);
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerViewBooks.setLayoutManager(mLayoutManager);
        BooksAdapter adapter = new BooksAdapter(getActivity(), booksList);
        recyclerViewBooks.setAdapter(adapter);

        booksViewModel.insert(mockBooksData());

        /*booksViewModel.getAllBooks().observe(this, new Observer<List<Books>>() {
            @Override
            public void onChanged(@Nullable final List<Books> words) {
                // Update the cached copy of the words in the adapter.
                adapter.setBooks(words);
            }
        });*/
        // if we use lamabda
        booksViewModel.getAllBooks().observe(this, words -> {
            // Update the cached copy of the words in the adapter.
            adapter.setBooks(words);
        });




        return view;

    }

    public static List<Books> mockBooksData() {

        String[] FIRST = new String[]{
                "Special edition", "New", "Cheap", "Quality", "Used"};
        String[] SECOND = new String[]{
                "Three-headed Monkey", "Rubber Chicken", "Pint of Grog", "Monocle"};
        String[] DESCRIPTION = new String[]{
                "is finally here", "is recommended by Stan S. Stanman",
                "is the best sold product on Mêlée Island", "is \uD83D\uDCAF", "is ❤️", "is fine"};
        List<Books> booksList = new ArrayList<>();
        Random rnd = new Random();
        for (int i = 0; i < FIRST.length; i++) {
            for (int j = 0; j < SECOND.length; j++) {
                Books book = new Books();
                book.setBookName(FIRST[i] + " " + SECOND[j]);
                book.setBookDescription(book.getBookName() + " " + DESCRIPTION[j]);
                book.setBookId(String.valueOf(FIRST.length * i + j + 1));
                book.setBookPrice("2000");
                booksList.add(book);
            }
        }
        return booksList;
    }
}
