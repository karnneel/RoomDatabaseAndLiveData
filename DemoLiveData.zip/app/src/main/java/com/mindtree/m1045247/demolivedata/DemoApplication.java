package com.mindtree.m1045247.demolivedata;

import android.app.Application;

import com.mindtree.m1045247.demolivedata.database.AppDatabase;

public class DemoApplication extends Application {

    AppExecutors appExecutors;

    @Override
    public void onCreate() {
        super.onCreate();
        appExecutors = new AppExecutors();
    }

    /*public AppDatabase getDatabase() {
        return AppDatabase.getInstance(this, appExecutors);
    }

    public DataRepository getRepository() {
        return DataRepository.getInstance(getDatabase());
    }*/
}
