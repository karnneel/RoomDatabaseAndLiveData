package com.mindtree.m1045247.demolivedata.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "ISBNTable")
public class ISBN {
    @PrimaryKey
    @NonNull
    String id;
    String name;

}
