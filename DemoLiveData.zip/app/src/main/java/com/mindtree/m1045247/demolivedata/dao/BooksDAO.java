package com.mindtree.m1045247.demolivedata.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.mindtree.m1045247.demolivedata.entity.Books;

import java.util.List;

@Dao
public interface BooksDAO {

    @Query("SELECT * FROM books_table")
    LiveData<List<Books>> loadAllBooks();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertBooksIntoDB(List<Books> booksList);

    @Insert
    void insertBook(Books book);

}
