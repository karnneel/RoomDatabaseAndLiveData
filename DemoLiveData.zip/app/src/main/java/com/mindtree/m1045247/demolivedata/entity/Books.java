package com.mindtree.m1045247.demolivedata.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "books_table")
public class Books {

    @PrimaryKey
    @NonNull
    String bookId;
    String bookName;
    String bookPrice;
    String bookDescription;

    public Books() {
    }


    @NonNull
    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookPrice() {
        return bookPrice;
    }

    public void setBookPrice(String bookPrice) {
        this.bookPrice = bookPrice;
    }

    public String getBookDescription() {
        return bookDescription;
    }

    public void setBookDescription(String bookDescription) {
        this.bookDescription = bookDescription;
    }

    public Books(Books books) {
        this.bookId = books.bookId;
        this.bookName = books.bookName;
        this.bookPrice = books.bookPrice;
        this.bookDescription = books.bookDescription;
    }
}