package com.mindtree.m1045247.demolivedata.viewmodel;

import android.app.Application;
import android.content.Context;

import com.mindtree.m1045247.demolivedata.AppExecutors;
import com.mindtree.m1045247.demolivedata.DataRepository;
import com.mindtree.m1045247.demolivedata.DemoApplication;
import com.mindtree.m1045247.demolivedata.entity.Books;

import java.util.List;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.Observer;

public class BooksViewModel extends AndroidViewModel {

    private DataRepository mRepository;
    private LiveData<List<Books>> mAllWords;

    public BooksViewModel(Application application) {
        super(application);
        mRepository = new DataRepository(application);

    }

    public LiveData<List<Books>> getAllBooks() {
        mAllWords = mRepository.getAllBooks();
        return mAllWords;
    }

    public void insert(List<Books> booksList) {
        mRepository.insert(booksList);
    }


}